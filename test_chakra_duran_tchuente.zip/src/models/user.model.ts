export type UserModel = {
    id: number;
    name: string;
    username: string;
    email: string;
    address: any;
  };